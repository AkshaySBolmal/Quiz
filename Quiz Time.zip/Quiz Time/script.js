 const startButton = document.getElementById('start-btn')
const nextButton = document.getElementById('next-btn')
const questionContainerElement = document.getElementById('question-container')
const questionElement = document.getElementById('question')
const answerButtonsElement = document.getElementById('answer-buttons')

let shuffledQuestions, currentQuestionIndex

startButton.addEventListener('click', startGame)
nextButton.addEventListener('click', () => {
  currentQuestionIndex++
  setNextQuestion()
})

function startGame() {
  startButton.classList.add('hide')
  shuffledQuestions = questions.sort(() => Math.random() - .5)
  currentQuestionIndex = 0
  questionContainerElement.classList.remove('hide')
  setNextQuestion()
}

function setNextQuestion() {
  resetState()
  showQuestion(shuffledQuestions[currentQuestionIndex])
}

function showQuestion(question) {
  questionElement.innerText = question.question
  question.answers.forEach(answer => {
    const button = document.createElement('button')
    button.innerText = answer.text
    button.classList.add('btn')
    if (answer.correct) {
      button.dataset.correct = answer.correct
    }
    button.addEventListener('click', selectAnswer)
    answerButtonsElement.appendChild(button)
  })
}

function resetState() {
  clearStatusClass(document.body)
  nextButton.classList.add('hide')
  while (answerButtonsElement.firstChild) {
    answerButtonsElement.removeChild(answerButtonsElement.firstChild)
  }
}

function selectAnswer(e) {
  const selectedButton = e.target
  const correct = selectedButton.dataset.correct
  setStatusClass(document.body, correct)
  Array.from(answerButtonsElement.children).forEach(button => {
    setStatusClass(button, button.dataset.correct)
  })
  if (shuffledQuestions.length > currentQuestionIndex + 1) {
    nextButton.classList.remove('hide')
  } else {
    startButton.innerText = 'Restart'
    startButton.classList.remove('hide')
  }
}

function setStatusClass(element, correct) {
  clearStatusClass(element)
  if (correct) {
    element.classList.add('correct')
  } else {
    element.classList.add('wrong')
  }
}

function clearStatusClass(element) {
  element.classList.remove('correct')
  element.classList.remove('wrong')
}

const questions = [
  {
    question: ' what is 2+2?',
    answers: [
      { text: '4', correct: true },
      { text: '22', correct: false }
    ]
  },
  {
    question: 'Who is the best YouTuber?',
    answers: [
      { text: 'Web Dev Simplified', correct: true },
      { text: 'Traversy Media', correct: true },
      { text: 'Dev Ed', correct: true },
      { text: 'Fun Fun Function', correct: true }
    ]
  },
  {
    question: 'Is web development fun?',
    answers: [
      { text: 'Kinda', correct: false },
      { text: 'YES!!!', correct: true },
      { text: 'Um no', correct: false },
      { text: 'IDK', correct: false }
    ]
  },
  {
    question: 'What is 4 * 2?',
    answers: [
      { text: '6', correct: false },
      { text: '8', correct: true }
    ]
  },
  {
    question: 'Where was the first modern Olympic Games held?',
    answers: [
      { text: 'Athens', correct: true },
      { text: 'Usa', correct: false},
      { text: 'Ussr', correct: false },
      { text: 'pakistan', correct: false }
    ]
  },
  {
    question: 'Which football team is known as ‘The Red Devils’?',
    answers: [
      { text: 'Argentina', correct:false },
      { text: 'Manchester United', correct: true },
      { text: 'barcelona', correct: false },
      { text: 'pakistan', correct: false }
    ]
  },
  {
    question: 'When was Netflix founded?',
    answers: [
      { text: '2001', correct:false },
      { text: '1997', correct: true },
      { text: '2007', correct: false },
      { text: '2012', correct: false }
    ]
  },
  {
    question: 'How many time zones are there in Russia?',
    answers: [
      { text: '20', correct:false },
      { text: '19', correct: false },
      { text: '17', correct: false },
      { text: '11', correct: true }
    ]
  },
  {
    question: 'Which of the following empires had no written language',
    answers: [
      { text: 'Egyptian', correct:false },
      { text: 'Aztec', correct: false },
      { text: 'Incan', correct: true },
      { text: 'Roman', correct: false }
    ]
  },
  {
    question: 'The Battle of Plassey was fought in',
    answers: [
      { text: '1856', correct:false },
      { text: '1755', correct: false },
      { text: '1854', correct: false },
      { text: '1757', correct: true }
    ]
  },
  {
    question: 'The theory of economic drain of India during British imperialism was propounded by',
    answers: [
      { text: 'Jawaharlal Nehru', correct:false },
      { text: 'R.C. Dutt', correct: false },
      { text: 'M.K. Gandhi', correct: false },
      { text: 'Dadabhai Naoroji', correct: true }
    ]
  },
  {
    question: 'The treaty of Srirangapatna was signed between Tipu Sultan and',
    answers: [
      { text: 'Robert Clive', correct:false },
      { text: 'R.C. Dutt', correct: false },
      { text: 'M.K.Roy', correct: false },
      { text: 'Cornwallis', correct: true }
    ]
  },
  {
    question: 'The treaty of Srirangapatna was signed between Tipu Sultan and',
    answers: [
      { text: '1852', correct:false },
      { text: '1810', correct: false },
      { text: '1854', correct: false },
      { text: '1833', correct: true }
    ]
  },
  {
    question: 'Through which one of the following, the king exercised his control over villages in the Vijayanagar Empire?',
    answers: [
      { text: 'Dannayaka', correct:false },
      { text: 'Nayaka', correct: false },
      { text: 'Mahanayakacharya', correct: true },
      { text: 'Sumanta', correct: false}
    ]
  },
  {
    question: 'The Vijayanagara ruler, Kirshnadev Rayas work Amuktamalyada, was in',
    answers: [
      { text: 'Telugu', correct:true },
      { text: 'Sanskrit', correct: false },
      { text: 'Tamil', correct: false },
      { text: 'Kannada', correct: false}
    ]
  },
  {
    question: 'What is part of a database that holds only one type of information?',
    answers: [
      { text: 'Report', correct:false },
      { text: 'Field', correct: true },
      { text: 'Record', correct: false },
      { text: 'File', correct: false}
    ]
  },
  {
    question: 'In which decade with the first transatlantic radio broadcast occur?',
    answers: [
      { text: '1904', correct:false },
      { text: '1901', correct: false },
      { text: '1855', correct: false },
      { text: '1900', correct: true}
    ]
  },
  {
    question: 'Which is a type of Electrically-Erasable Programmable Read-Only Memory?',
    answers: [
      { text: 'flash', correct:true },
      { text: 'flag', correct: false },
      { text: 'fury', correct: false },
      { text: 'flange', correct: false}
    ]
  },
  {
    question: ' What frequency range is the High Frequency band?',
    answers: [
      { text: '100khz', correct:false },
      { text: '1ghz', correct: false },
      { text: '30 t 300mhz', correct: false },
      { text: '3 to 30mhz', correct: true}
    ]
  },
  {
    question: ' What do we call a network whose elements may be separated by some distance? It usually involves two or more small networks and dedicated high-speed telephone lines.',
    answers: [
      { text: 'url', correct:false },
      { text: 'lan', correct: false },
      { text: 'wan', correct: true },
      { text: 'www', correct: false}
    ]
  },
]